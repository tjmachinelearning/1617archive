import numpy as np
import random

def __init__(self, sizes):
    self.layers = len(sizes)
    self.biases = [np.random.randn(y, 1) for y in sizes[1:]]
    self.weights = [np.random.randn(y, x) for x, y in zip(sizes[:-1], sizes[1:])]

# return network output
#input is an (n, 1) Numpy ndarray
def feedforward(self, input):
